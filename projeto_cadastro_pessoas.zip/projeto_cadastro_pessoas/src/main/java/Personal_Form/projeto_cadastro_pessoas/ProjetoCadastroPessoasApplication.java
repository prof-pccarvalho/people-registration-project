package Personal_Form.projeto_cadastro_pessoas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoCadastroPessoasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoCadastroPessoasApplication.class, args);
	}

}
