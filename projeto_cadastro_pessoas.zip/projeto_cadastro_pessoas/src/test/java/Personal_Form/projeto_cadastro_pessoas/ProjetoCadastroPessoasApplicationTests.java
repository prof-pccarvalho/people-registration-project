package Personal_Form.projeto_cadastro_pessoas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoCadastroPessoasApplicationTests {

	@Test
	void contextLoads() {
	}

}
